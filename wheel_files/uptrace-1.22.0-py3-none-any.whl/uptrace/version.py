"""Uptrace distro version"""

__version__ = "1.22.0"
