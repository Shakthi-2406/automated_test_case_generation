from langchain_community.document_loaders.blob_loaders.youtube_audio import (
    YoutubeAudioLoader,
)

__all__ = ["YoutubeAudioLoader"]
