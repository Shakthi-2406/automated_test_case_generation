from langchain_community.document_loaders.obs_file import OBSFileLoader

__all__ = ["OBSFileLoader"]
