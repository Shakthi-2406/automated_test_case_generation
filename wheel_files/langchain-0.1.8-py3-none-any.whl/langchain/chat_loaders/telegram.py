from langchain_community.chat_loaders.telegram import TelegramChatLoader

__all__ = ["TelegramChatLoader"]
