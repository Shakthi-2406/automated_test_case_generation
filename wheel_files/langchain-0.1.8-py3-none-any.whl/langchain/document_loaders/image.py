from langchain_community.document_loaders.image import UnstructuredImageLoader

__all__ = ["UnstructuredImageLoader"]
