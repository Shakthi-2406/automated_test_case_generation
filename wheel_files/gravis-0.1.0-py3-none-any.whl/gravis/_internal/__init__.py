"""A subpackage for providing public and hiding non-public functionality."""
